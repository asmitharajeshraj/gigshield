import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface UserProfile {
  phone: string;
  name: string;
  platform: 'zomato' | 'swiggy';
  workerId: string;
  riskScore: number;
  city: string;
  pincode: string;
  upiId: string;
  totalEarnings: number;
  deliveries: number;
  memberSince: string;
}

export interface Claim {
  id: string;
  date: string;
  type: string;
  amount: number;
  status: 'paid' | 'processing' | 'rejected';
  trigger: string;
}

export interface AppState {
  user: UserProfile | null;
  selectedTier: 'bronze' | 'silver' | 'gold' | null;
  isAuthenticated: boolean;
  language: 'en' | 'hi';
  coverageActive: boolean;
  alertActive: boolean;
  claims: Claim[];
  notifications: number;
}

interface AppContextType extends AppState {
  setUser: (user: UserProfile | null) => void;
  setSelectedTier: (tier: 'bronze' | 'silver' | 'gold' | null) => void;
  setAuthenticated: (val: boolean) => void;
  setLanguage: (lang: 'en' | 'hi') => void;
  setCoverageActive: (val: boolean) => void;
  setAlertActive: (val: boolean) => void;
  logout: () => void;
}

const defaultClaims: Claim[] = [
  { id: 'CLM001', date: '2026-03-14', type: 'Heavy Rain', amount: 420, status: 'paid', trigger: '🌧️ IMD Rain >50mm' },
  { id: 'CLM002', date: '2026-03-07', type: 'App Crash', amount: 350, status: 'paid', trigger: '📱 Zomato Outage 3h' },
  { id: 'CLM003', date: '2026-02-22', type: 'AQI Alert', amount: 210, status: 'paid', trigger: '💨 AQI >300 Severe' },
  { id: 'CLM004', date: '2026-02-10', type: 'Curfew', amount: 420, status: 'processing', trigger: '🚫 Section 144' },
  { id: 'CLM005', date: '2026-01-28', type: 'Heatwave', amount: 180, status: 'rejected', trigger: '🌡️ Heat 42°C' },
];

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [selectedTier, setSelectedTier] = useState<'bronze' | 'silver' | 'gold' | null>(null);
  const [isAuthenticated, setAuthenticated] = useState(false);
  const [language, setLanguage] = useState<'en' | 'hi'>('en');
  const [coverageActive, setCoverageActive] = useState(true);
  const [alertActive, setAlertActive] = useState(false);
  const [claims] = useState<Claim[]>(defaultClaims);
  const [notifications] = useState(3);

  const logout = () => {
    setUser(null);
    setAuthenticated(false);
    setSelectedTier(null);
  };

  return (
    <AppContext.Provider value={{
      user, setUser,
      selectedTier, setSelectedTier,
      isAuthenticated, setAuthenticated,
      language, setLanguage,
      coverageActive, setCoverageActive,
      alertActive, setAlertActive,
      claims,
      notifications,
      logout,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
