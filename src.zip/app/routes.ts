import { createBrowserRouter } from 'react-router';
import { SignIn } from './components/screens/SignIn';
import { KYCSetup } from './components/screens/KYCSetup';
import { PremiumSelect } from './components/screens/PremiumSelect';
import { Dashboard } from './components/screens/Dashboard';
import { AlertScreen } from './components/screens/AlertScreen';
import { PayoutScreen } from './components/screens/PayoutScreen';
import { ClaimsHistory } from './components/screens/ClaimsHistory';
import { Profile } from './components/screens/Profile';
import { Notifications } from './components/screens/Notifications';
import { MobileLayout } from './components/layout/MobileLayout';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { FraudDetection } from './components/admin/FraudDetection';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: SignIn,
  },
  {
    path: '/kyc',
    Component: KYCSetup,
  },
  {
    path: '/premium',
    Component: PremiumSelect,
  },
  {
    path: '/app',
    Component: MobileLayout,
    children: [
      { path: 'dashboard', Component: Dashboard },
      { path: 'alert', Component: AlertScreen },
      { path: 'alerts', Component: Notifications },
      { path: 'payout', Component: PayoutScreen },
      { path: 'claims', Component: ClaimsHistory },
      { path: 'profile', Component: Profile },
    ],
  },
  {
    path: '/admin',
    Component: AdminDashboard,
  },
  {
    path: '/admin/fraud',
    Component: FraudDetection,
  },
]);
